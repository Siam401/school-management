<div class="panel panel-default">
<div class="panel-body">
  <table class="table table-bordered">
	 <tr><td>{{ _lang('Category Name') }}</td><td>{{ $postcategory->category }}</td></tr>
			<tr><td>{{ _lang('Note') }}</td><td>{{ $postcategory->note }}</td></tr>
			<tr><td>{{ _lang('Parent Category') }}</td><td>{{ $postcategory->parent_id }}</td></tr>
			
  </table>
</div>
</div>
