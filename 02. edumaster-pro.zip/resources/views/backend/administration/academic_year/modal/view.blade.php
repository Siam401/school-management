<div class="panel panel-default">
    <div class="panel-body">
        <table class="table table-bordered">
            <tr>
                <td>{{ _lang('Session') }}</td>
                <td>{{ $academicYear->session }}</td>
            </tr>
            <tr>
                <td>{{ _lang('Year') }}</td>
                <td>{{ $academicYear->year }}</td>
            </tr>
        </table>
    </div>
</div>
