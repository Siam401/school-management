<div class="panel panel-default">
<div class="panel-body">
  <table class="table table-bordered">
	 <tr><td>{{ _lang('Type') }}</td><td>{{ $picklist->type }}</td></tr>
			<tr><td>{{ _lang('Value') }}</td><td>{{ $picklist->value }}</td></tr>
			
  </table>
</div>
</div>
