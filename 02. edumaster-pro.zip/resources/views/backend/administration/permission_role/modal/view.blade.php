<div class="panel panel-default">
<div class="panel-body">
  <table class="table table-bordered">
	 <tr><td>{{ _lang('Role Name') }}</td><td>{{ $role->role_name }}</td></tr>
			<tr><td>{{ _lang('Note') }}</td><td>{{ $role->note }}</td></tr>
			
  </table>
</div>
</div>
