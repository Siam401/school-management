<div class="panel panel-default">
<div class="panel-body">
  <table class="table table-bordered">
	 <tr><td>{{ _lang('Group Name') }}</td><td>{{ $studentgroup->group_name }}</td></tr>
			
  </table>
</div>
</div>
