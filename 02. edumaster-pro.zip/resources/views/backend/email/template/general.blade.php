<h2>{{ $content->subject }}</h2><br>
{!! $content->message  !!}

<br><br>
<p>{{ _lang('Best regards') }}</p>
<p>{{ get_option('school_name') }}</p>


