<div class="panel panel-default">
<div class="panel-body">
  <table class="table table-bordered">
	 <tr><td>{{ _lang('Name') }}</td><td>{{ $payeepayer->name }}</td></tr>
			<tr><td>{{ _lang('Type') }}</td><td>{{ $payeepayer->type }}</td></tr>
			<tr><td>{{ _lang('Note') }}</td><td>{{ $payeepayer->note }}</td></tr>
			
  </table>
</div>
</div>
