<div class="panel panel-default">
    <div class="panel-body">
        <table class="table table-bordered">
            <tr>
                <td>{{ _lang('Payment Method Name') }}</td>
                <td>{{ $paymentmethod->name }}</td>
                <td>{{ $paymentmethod->balance }}</td>
            </tr>

        </table>
    </div>
</div>
