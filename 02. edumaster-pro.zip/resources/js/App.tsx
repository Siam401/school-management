import React from "react";

export default function App() {
  console.log("Loading vite changed.");

  return (
    <div>
      <h1>React App</h1>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae
        porro atque animi earum voluptatibus tempora, enim molestiae provident.
        Minima officia nam temporibus. Nisi porro consectetur cumque iure
        placeat modi eos!
      </p>
    </div>
  );
}
